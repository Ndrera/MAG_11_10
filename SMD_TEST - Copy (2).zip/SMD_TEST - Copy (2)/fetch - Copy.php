<?php
require_once 'core/init.php';


#FETCH ALL THE DATA FROM DB
$data = DB::getInstance()->query("SELECT * FROM users");


$output = '';
if( !$data->count() ){

	$output .= "
      <ul class='list-group'>
     	<li class='list-group-item'>
     	   <div class='alert alert-danger'>
     	      Sorry we currently dont have any data to show at the moment.<br/> Please try again tommorrow.
     	   </div>

     	   <a href='contact.php'>
     	     <button type='button' name='back' class='btn btn-primary btn-block back' id=' '>Back To Contact</button>
     	   </a>  

     	</li>
      </ul>
    ";

}else{

	$x = 1;
	foreach( $data->results() as $result ){

		$phone_number = substr($result->phone_number , 1);
		$phone_number = "+27" . $phone_number;

		$output .= "
	       <ul class='list-group'>
			   	   <li class='list-group-item'><b>Name:</b> <br/>  $result->name</li>
			   	   <li class='list-group-item'><b>Email:</b> <br/>  $result->email</li>
			   	   <li class='list-group-item'><b>Phone Number:</b> <br/>  $phone_number</li>

			   	   <li class='list-group-item'><b>Date of Birth:</b> <br/>  $result->date_of_birth</li>
			   	   <li class='list-group-item'><b>Gender:</b> <br/>  $result->gender</li>
			   	   <li class='list-group-item'><b>ID Number:</b> <br/>  $result->id_number</li>

			   	   <li class='list-group-item'><b>Car Make:</b> <br/>  $result->car_make</li>
			   	   <li class='list-group-item'><b>Car Color:</b> <br/>  $result->car_color</li>
			   	   <li class='list-group-item'><b>Car Registration:</b> <br/>  $result->car_registration</li>

		   </ul>
		";

		$output .= $x < count( $data->results() ) ? "<hr/>" : "";
		$x++;
	}
}


echo $output;

?>