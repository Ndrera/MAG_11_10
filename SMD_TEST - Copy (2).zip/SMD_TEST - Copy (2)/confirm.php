<?php
require_once 'core/init.php';


//echo "WE ARE CONFIRMING PAYMENT";
//echo Input::get('confirm_id');

$db = DB::getInstance();

$id = Input::get('confirm_id'); 


try{
	#UPDATE THE CREDIT  
	$db->update( 'credits', $id, array(	

		'payment'      	=> "Success",
		'updated_at' 	=> date('Y-m-d H:i:s')

	) );

	echo "Invoice payment confirmed";

}catch( Exception $e ){
	die( $e->getMessage() );
} 


?>