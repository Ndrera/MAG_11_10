<footer id="footer" class="text-center">
	<p>Copyright <?php echo date("Y"); ?> &copy; TRF</p>
</footer>