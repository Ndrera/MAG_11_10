<?php
require_once 'core/init.php';


//echo "WE ARE SUSPENDING PPL";
//echo Input::get('suspend_id');


$db = DB::getInstance();

$id = Input::get('suspend_id');


//SELECT STATUS, updated_at FROM `clients` WHERE id = 1
$data = $db->query("SELECT c.status, updated_at FROM clients c WHERE id = $id");
//var_dump($data );


if( !$data->count() ){
    #NO DATA FOUND IN THE DATABASE
	echo "No client data found";

}else{

	 foreach( $data->results() as $result ){
	 	
	 	if( $result->status == 1 ){
	 		$status = 0;

	 	}else{
	 		$status = 1;
	 	}


	 }

	// var_dump($statuts);
	// echo $status;
	 


	 
	 #UPDATE THE STATUS
	 try{
	 #UPDATE THE CREDIT  

			$db->update( 'clients', $id, array(	

				'status'      	=> $status,
				'updated_at' 	=> date('Y-m-d H:i:s')
				

			) );

			echo "You have updated the status";

	 }catch( Exception $e ){
		die( $e->getMessage() );
	 } 



}






?>