-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 10, 2020 at 03:52 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dev_project_smd`
--

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `id` int(11) NOT NULL,
  `trade_name` varchar(70) NOT NULL,
  `registered_name` varchar(70) NOT NULL,
  `client_code` varchar(100) NOT NULL,
  `business_email` varchar(50) NOT NULL,
  `emp_email` varchar(50) NOT NULL,
  `business_contact_number` varchar(12) NOT NULL,
  `emp_contact_number` varchar(12) NOT NULL,
  `physical_address` varchar(100) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `deleted_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`id`, `trade_name`, `registered_name`, `client_code`, `business_email`, `emp_email`, `business_contact_number`, `emp_contact_number`, `physical_address`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Ramama', 'Ramama construction', 'RA1000M', 'business@ramama.com', 'michael@ramama.com', '0120011111', '0761231456', 'B2180 Jomo Str, Emondlo, 3105', 1, '2020-11-06 12:34:18', '2020-11-10 15:45:42', '2020-11-06 12:34:18'),
(2, 'Nhlahla Catering & Constructio', 'Rapulane Construction', 'NH1001M', 'ncc@rapulane.co.za', 'nahlahla@rapulane.co.za', '0349910111', '0741233456', 'NO.301 2nd Avanue, Vryheid, 3105', 0, '2020-11-06 12:34:18', '2020-11-06 12:34:18', '2020-11-06 12:34:18'),
(3, 'Ramama', 'Ramama construction', 'RA1000M', 'business@ramama.com', 'michael@ramama.com', '0120011111', '0761231456', 'B2180 Jomo Str, Emondlo, 3105', 0, '2020-11-06 12:34:18', '2020-11-06 12:34:18', '2020-11-06 12:34:18'),
(4, 'Nhlahla Catering & Constructio', 'Rapulane Construction', 'NH1001M', 'ncc@rapulane.co.za', 'nahlahla@rapulane.co.za', '0349910111', '0741233456', 'NO.301 2nd Avanue, Vryheid, 3105', 0, '2020-11-06 12:34:18', '2020-11-06 12:34:18', '2020-11-06 12:34:18');

-- --------------------------------------------------------

--
-- Table structure for table `credits`
--

CREATE TABLE `credits` (
  `id` int(11) NOT NULL,
  `client_name` varchar(70) NOT NULL,
  `client_id` int(11) NOT NULL,
  `available_credit` int(11) NOT NULL,
  `load_credit` text NOT NULL,
  `credit_status` varchar(20) NOT NULL DEFAULT 'Active',
  `credits_issued_to_date` int(11) NOT NULL,
  `payment` varchar(60) NOT NULL DEFAULT 'Pending',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `deleted_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `credits`
--

INSERT INTO `credits` (`id`, `client_name`, `client_id`, `available_credit`, `load_credit`, `credit_status`, `credits_issued_to_date`, `payment`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Ramama', 1, 220, '{credit1:10,credit2:20,credit3:30,credit4:40,credit5:50,credit6:60,credit7:70,credit8:80,credit9:90,credit10:100,credit11:150,credit12:200}', '1', 10200, 'Success', '2020-11-06 14:00:55', '2020-11-10 15:40:30', '2020-11-06 14:00:55'),
(3, 'Nhlahla Catering & Construction', 2, 80, '{credit1:10,credit2:20,credit3:30,credit4:40,credit5:50,credit6:60,credit7:70,credit8:80,credit9:90,credit10:100,credit11:150,credit12:200}', 'Active', 500, 'Success', '2020-11-06 14:07:58', '2020-11-10 14:52:31', '2020-11-06 14:07:58');

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE `groups` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `permissions` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `invoices`
--

CREATE TABLE `invoices` (
  `id` int(11) NOT NULL,
  `credit_id` int(11) NOT NULL,
  `invoice_no` varchar(100) NOT NULL,
  `sales_rep` varchar(60) NOT NULL,
  `invoice_recipient_name` varchar(100) NOT NULL,
  `recipient_address_line1` varchar(60) NOT NULL,
  `recipient_address_line2` varchar(60) NOT NULL,
  `recipient_address_line3` varchar(60) NOT NULL,
  `recipient_address_line4` varchar(60) NOT NULL,
  `description` varchar(100) NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` float NOT NULL,
  `total_price` float NOT NULL,
  `status` int(1) NOT NULL DEFAULT 0,
  `due_date` datetime NOT NULL,
  `created_at` date NOT NULL,
  `updated_at` datetime NOT NULL,
  `deleted_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `invoices`
--

INSERT INTO `invoices` (`id`, `credit_id`, `invoice_no`, `sales_rep`, `invoice_recipient_name`, `recipient_address_line1`, `recipient_address_line2`, `recipient_address_line3`, `recipient_address_line4`, `description`, `quantity`, `unit_price`, `total_price`, `status`, `due_date`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 3, 'MS001', 'A.I.S', 'Motor Accident Group', '80 Booysens Road', 'Selby', '2001', '', 'Advanced Intelligence System', 100, 35, 3500, 0, '2020-12-09 10:27:55', '2020-11-09', '2020-11-09 10:27:55', '2020-11-09 10:27:55'),
(2, 1, 'MAG001', 'A.I.S', 'Ramama construction', 'B2180 Jomo Str, Emondlo, 3105', '', '', '', 'Advanced Intelligence System', 100, 35, 2975, 0, '2020-12-10 00:00:00', '2020-11-10', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(3, 1, 'MAG001', 'A.I.S', 'Ramama construction', 'B2180 Jomo Str, Emondlo, 3105', '', '', '', 'Advanced Intelligence System', 200, 35, 5950, 0, '2020-12-10 00:00:00', '2020-11-10', '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `email` varchar(60) NOT NULL,
  `password` varchar(128) NOT NULL,
  `salt` varchar(32) NOT NULL,
  `name` varchar(50) NOT NULL,
  `created_at` datetime NOT NULL,
  `group` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `salt`, `name`, `created_at`, `group`) VALUES
(7, 'Baba', 'baba@gmail.com', '502789cec96e5ac56e35ed548a198878d2a8d26594de98ea8ba3dfe67fdea1a4', '?C??z*SC??\'???k?`o?FXXLO?ނ?s', 'Babawethu', '2020-11-05 08:12:28', 1),
(9, 'Sonini', 'Sonini@gmail.com', '0b4ad1051e8a3774a95db2ac9b9cb2970133ff94e15fb082d72249e928f7c959', '$(*&%$@e03e5bd3a1d64fa2d7aafd866', 'Sonini Nanin', '2020-11-05 08:52:59', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users_session`
--

CREATE TABLE `users_session` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `hash` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `credits`
--
ALTER TABLE `credits`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `groups`
--
ALTER TABLE `groups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `invoices`
--
ALTER TABLE `invoices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users_session`
--
ALTER TABLE `users_session`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `clients`
--
ALTER TABLE `clients`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `credits`
--
ALTER TABLE `credits`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `groups`
--
ALTER TABLE `groups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `invoices`
--
ALTER TABLE `invoices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `users_session`
--
ALTER TABLE `users_session`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
