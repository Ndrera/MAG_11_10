<?php
//action.php

require_once 'core/init.php';


if( Input::exists() ){
	if( Token::check( Input::get('token') ) ){

 		/*
		if( Input::get('action') == 'insert' ){

			$form_data = array(
				'name'     		  	=> Input::get('name'),
				'email'  		  	=> Input::get('email'),
				'phone_number'    	=> Input::get('phone_number'),

				'date_of_birth'	  	=> Input::get('date_of_birth'),
				'gender'          	=> Input::get('gender'),
				'id_number' 	  	=> Input::get('id_number'),

				'car_make'			=> Input::get('car_make'),
				'car_color'			=> Input::get('car_color'),
				'car_registration'	=> Input::get('car_registration')				

			);
	

			$api_url = "http://localhost/SMD_TEST/api.php?action=insert";

			$client =curl_init( $api_url );

			curl_setopt($client, CURLOPT_POST, true);
		    curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);
		    curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

			$response = curl_exec($client);

			curl_close($client);
			
			echo $response;		    
			
		} */


		#ADD A NEW USER [ add_user ]
		if( Input::get('action') == 'add_user' ){

			//var_dump("WE ARE ADDIND A NEW USER"); die;

			$form_data = array(
				'company_name'     	=> Input::get('company_name'),
				'username'      	=> Input::get('username'),
				'email'  		  	=> Input::get('email'),
				'password'          => Input::get('password'),
				'name'				=> Input::get('name'),
				'password_again'    => Input::get('password_again')
				
			);
	

			/*** START
			if( "Its Local Server" ){
				$api_url = "http://localhost/SMD_TEST/api.php?action=insert";

			}else{
				$api_url = "https://198.0.4.8:8080/SMD_TEST/api.php?action=insert";
			} 
			

			#SECOND TEST
			if( https ){   //$_SERVER['HTTPS_HOST']
				$path = str_replace("\\",'/',"https://".$_SERVER['HTTP_HOST'].substr(getcwd(),strlen($_SERVER['DOCUMENT_ROOT'])));

			}else if( http ){  //$_SERVER['HTTP_HOST']
				$path = str_replace("\\",'/',"http://".$_SERVER['HTTP_HOST'].substr(getcwd(),strlen($_SERVER['DOCUMENT_ROOT'])));
			}

			END **/



			#GET THE REAL PATH FROM THE SERVER
			// echo str_replace("\\",'/',"http://".$_SERVER['HTTP_HOST'].substr(getcwd(),strlen($_SERVER['DOCUMENT_ROOT'])));
			/*
			 if(isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on')   
		         $url = "https://";   

		    else {
				//$url = "http://

		    }
			*/

			



			#HARD CODED URL
			//$api_url = "http://localhost/SMD_TEST/api.php?action=insert";
			//$api_url = "http://localhost/SMD_TEST/api.php?action=add_user";

			
			/********
			#WORKS FINE
            $path = str_replace("\\",'/',"http://".$_SERVER['HTTP_HOST'].substr(getcwd(),strlen($_SERVER['DOCUMENT_ROOT'])));
            $api_url = $path . "/api.php?action=add_user";
			*********/
			
			if(isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on'){
				 #NOTE: HARD CODING IS ALSO  AN OPTION

		         #"https://";
		         $path = str_replace("\\",'/',"https://".$_SERVER['HTTPS_HOST'].substr(getcwd(),strlen($_SERVER['DOCUMENT_ROOT'])));
            	 $api_url = $path . "/api.php?action=add_user"; 

		    }else {

				#"http://";
				 $path = str_replace("\\",'/',"http://".$_SERVER['HTTP_HOST'].substr(getcwd(),strlen($_SERVER['DOCUMENT_ROOT'])));
           		 $api_url = $path . "/api.php?action=add_user";

		    }


			$client =curl_init( $api_url );

			curl_setopt($client, CURLOPT_POST, true);
		    curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);
		    curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

			$response = curl_exec($client);

			curl_close($client);
			
			//echo $response;

			if(  $response == 1 ){
				echo $response;
			}else{
				echo $response;
			}
			

			
		}





	}
}

?> 