<?php
require_once 'core/init.php';


#NOTE: ITS clients TB
/*
<tr>
  <th scope="row">1</th>
  <td>AMT Autobody</td>
  <td>AT1001M</td>
  <td>business@amt.co.za</td>
  <td>0124561781</td>
  <td>2020-11-05 08:52:59</td>
  <td><button class="btn btn-danger btn-block">Ban</button></td>
  <td><button class="btn btn-primary btn-block">Update</button></td>
</tr>

`id`, `trade_name`, `registered_name`, `client_code`, `business_email`, `emp_email`, `business_contact_number`, 
`emp_contact_number`, `physical_address`, `status`, `created_at`, `updated_at`, `deleted_at`

*/

$data = DB::getInstance()->query("SELECT * FROM clients");

//var_dump( $data );

$output = '';
$option = '';
$active_button = '';
if( !$data->count() ){
    #NO DATA FOUND IN THE DATABASE
	$output .= "
	<tr>
	    <td>No table records are found on this table.</td>
	</tr>
	";

}else{



	$x = 1;
	foreach( $data->results() as $result ){


		//<button type="button" name="suspend" id="' . $result->id . '" class="btn btn-danger btn-block suspend">Suspend</button>

		if( $result->status == 1 ){
	  		$active_button = '<button type="button" name="suspend" id="' . $result->id . '" class="btn btn-danger btn-block suspend">Un-Suspend</button>';
	  	}else{
	  		$active_button = '<button type="button" name="suspend" id="' . $result->id . '" class="btn btn-danger btn-block suspend">Suspend</button>';
	  	}
         
		$output .= '
		    <tr>
		      <th scope="row">'. $result->id .'</th>
		      <th scope="row">' . $result->registered_name . '</th>
		      <td>' . $result->client_code . '</th>
		      <td>' . $result->business_email . '</th>
		      <td>' . $result->business_contact_number . '</th>
		      <td>' . $result->created_at . '</th>
		      <td>' . $active_button  . '</td>
		      <td><button type="button" name="edit" id="' . $result->id . '" class="btn btn-primary btn-block edit">Edit</button></td>
		    </tr>
		    ';


		$output .= $x < count( $data->results() ) ? "<hr/>" : "";
		$x++;

		
	}



}


echo $output;

?>