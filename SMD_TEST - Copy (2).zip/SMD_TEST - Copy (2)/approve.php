<?php
require_once 'core/init.php';
require('fpdf182/fpdf.php');



//CREATING AN INVOICE TABLE DATA
//echo "APPROVE BUTTON";

/*
BUTTON [ Approve Credit  (Loads credits)]
TB: credits
- First calculate the invoice amount [ credist * 35 * vat ]  [DONE]
- add loaded_credits to available_credits
- save the invoices TB data
- Then generate a pdf invoice, then send it to the clients_email
- */

/*
`id`, `credit_id`, `invoice_no`, `sales_rep`, `invoice_recipient_name`, `recipient_address_line1`, `recipient_address_line2`,
`recipient_address_line3`, `recipient_address_line4`, `description`, `quantity`, `unit_price`, `total_price`, `status`, `due_date`, 
`created_at`, `updated_at`, `deleted_at`
*/
//echo Input::get('approve_id');
//echo Input::get('value');

#GET CLIENTS DATA
/*
 SELECT cl.registered_name, cl.business_email, cl.physical_address
FROM `credits` cr
INNER JOIN `clients` cl ON cr.`client_id` = cl.id
WHERE cr.id = 1;

cl.registered_name, cl.business_email, cl.physical_address

- available_credit [ $db_available credits + form credits ]
- credits_issued_to_date [ $db_available credits + form credits ]
- upated_date

SELECT cl.registered_name, cl.business_email, cl.physical_address, cr.`available_credit`, cr.`credits_issued_to_date`
FROM `credits` cr
INNER JOIN `clients` cl ON cr.`client_id` = cl.id
WHERE cr.id = 1;
*/

$db = DB::getInstance();

$registered_name = '';
$business_email = '';
$physical_address = '';

$credit_id = Input::get('approve_id');
$credit = Input::get('value');

/*
$data = DB::getInstance()->query("SELECT cl.registered_name, cl.business_email, cl.physical_address FROM `credits` cr INNER JOIN `clients` cl ON cr.`client_id` = cl.id WHERE cr.id = 1");*/

$data = $db->query("SELECT cl.registered_name, cl.business_email, cl.physical_address, cr.available_credit, cr.credits_issued_to_date FROM `credits` cr INNER JOIN `clients` cl ON cr.`client_id` = cl.id WHERE cr.id = 1");

//var_dump( $data );

$output = '';
$option = '';
if( !$data->count() ){
    #NO DATA FOUND IN THE DATABASE
	$output .= "
	<tr>
	    <td>This client is not found in our clients table records</td>
	</tr>
	";

}else{
   
    //$x = 1;
	foreach( $data->results() as $result ){
		//var_dump( $result->registered_name );
		$result->registered_name;
		$result->business_email;
		$result->physical_address;
		$result->available_credit;
		$result->credits_issued_to_date;
	}


	try{
	#UPDATE THE CREDIT  

			$db->update( 'credits', $credit_id, array(	

				'available_credit'      	=> $result->available_credit + $credit,
				'credits_issued_to_date'  	=> $result->credits_issued_to_date + $credit,
				'updated_at' 			=> date('Y-m-d H:i:s')
				

			) );

			//echo "Credit updated";

	}catch( Exception $e ){
		die( $e->getMessage() );
	} 



}

/*
$credit_id = Input::get('approve_id');
$credit = Input::get('value');
*/

echo "Credit ID: " . $credit_id . "<br/>";
echo "Credits . eg (100):  " . $credit_id . "<br/>";

$vat = (float) 0.15;  //15%
$unit_price =  (float) 35.00;
#CALCULATE THE TOTAL PRICE  [ (credit * unit_price ) * 0.15 ]
$total_vat = ($credit * $unit_price) * $vat;
$total = ($credit * $unit_price);

$total_price = $total - $total_vat;

echo "TOTAL PRICE:  " . $total_price . "<br/>";

#TAKE THE ID and ADD MAG00 . $credit_id
$invoice_no = "MAG00" . $credit_id;
echo "INVOICE NO:" . $invoice_no . "<br/>";


#Sales_rep
$sales_rep = "A.I.S";
echo "SALES REP: " .$sales_rep . "<br/>";

#invoice_recipient_name
$recipient_name = $result->registered_name ;
echo "Invoice Recipient Name: " .$recipient_name. "<br/>";

#irecipient_address_line1
$physical_address = $result->physical_address ;
echo "Address: " .$physical_address. "<br/>";

#JUMP:  `recipient_address_line2, `recipient_address_line3`, `recipient_address_line4`


#description     [ Advanced Intelligence System ]
$description = "Advanced Intelligence System";
echo "Discription: " . $description . "<br/>";


#quantity
$quantity = $credit;
echo "Quantity: " . $quantity . "<br/>";

#unit_price
echo "Unit Price: " . $unit_price. "<br/>";


#total_price
echo "Total Price: " . $total_price. "<br/>";

#status  [ Ommite For NOW ]



/*
$time = strtotime( $result->created_at );
$final = date("Y-m-d", strtotime("+1 month", $time));
*/
#due_date
$time = strtotime( date("Y-m-d") );
$due_date = date("Y-m-d", strtotime("+1 month", $time));
echo "Due Date: " . $due_date . "<br/>";

#created_at
$created_at = date("Y-m-d");
echo "Created At: " . $created_at . "<br/>";

#JUMP: `updated_at`, `deleted_at`




//var_dump( $salt  ); die;

try{
	#Create a new user
	//$db = DB::getInstance();

	$save = $db->insert( 'invoices', array(	
					/*
TB: invoices
`id`, `credit_id`, `invoice_no`, `sales_rep`, `invoice_recipient_name`, `recipient_address_line1`, `recipient_address_line2`,`recipient_address_line3`, `recipient_address_line4`, 
`description`, `quantity`, `unit_price`, `total_price`, `status`, `due_date`, 
`created_at`, `updated_at`, `deleted_at`
					***/

		'credit_id'    	=> $credit_id,
		'invoice_no'	=> $invoice_no,
		'sales_rep'	  	=> $sales_rep,
		'invoice_recipient_name'		 	=> $recipient_name,
		'recipient_address_line1'        	=> $physical_address,
		'description'        	=> $description,
		'quantity'        		=> $quantity,
		'unit_price'        	=> $unit_price,
		'total_price'        	=> $total_price,
		'due_date'        		=> $due_date,
		'created_at' 			=> date('Y-m-d H:i:s')
		

	) );

	//Session::flash( 'output', "<div class='alert alert-success'>The new user has been successfully added!</div>" );
	echo "Invoice CREATED";

	#SEND AN EMAIL INVOIVICE IF ITS SUCCESS FULL
	if( $save ){
		#SEND AN EMAIL WITH THE INVOICE
		/*
		SELECT * FROM `invoices` WHERE `credit_id` = $credit_id ORDER BY id DESC LIMIT 1
		*/

		$data = $db->query("SELECT * FROM invoices WHERE credit_id = $credit_id ORDER BY id DESC LIMIT 1");



		//var_dump( $data ); die;

		if( !$data->count() ){
		    #NO DATA FOUND IN THE DATABASE
		   

			echo "No invoice data found";

		}else{
		   // echo "Yes We found the data";
			 $x = 1;
			foreach( $data->results() as $result ){
				

		       /*A4 width : 219mm*/

				$pdf = new FPDF('P','mm','A4');

				$pdf->AddPage();
				/*output the result*/

				/*set font to arial, bold, 14pt*/
				$pdf->SetFont('Arial','B',20);

				/*Cell(width , height , text , border , end line , [align] )*/

				#HEAGING [ INVOICE ]
				#BLOCK 1
				$pdf->Cell(71 ,10,'',0,0);
				$pdf->Cell(59 ,5,'INVOICE',0,0);
				$pdf->Cell(59 ,10,'',0,1);

				#SENDER'S ADDRESS AND DETAILS [ e.p Platinum I.C.T ]
				#BLOCK 2
				$pdf->SetFont('Arial','B',15);
				$pdf->Cell(71 ,5,'Invoice From:',0,0);
				$pdf->Cell(59 ,5,'',0,0);
				$pdf->Cell(59 ,5,'Invoice Details:',0,1);

				#$pdf->SetFont('Arial','',10);
				$pdf->SetFont('Arial','B',10);

				#NOTE: IT JUMPS FROM LINE TO LINE
				#NOTE: WHERE YOU WANT TO OMMITE DATA LEAVE BLANK [e.g ,'']
				$pdf->Cell(130 ,5,'',0,0);    //ADDIND SPACE
				$pdf->Cell(25 ,5,'',0,0);
				$pdf->Cell(34 ,5,'',0,1);

				$pdf->Cell(130 ,5,'Platinum ICT (Pty) LTD',0,0);  
				$pdf->Cell(25 ,5,'Invoice No:',0,0);
				$pdf->Cell(34 ,5, $result->invoice_no,0,1);

				$pdf->Cell(130 ,5,'VAT No: 4380274177',0,0);
				$pdf->Cell(25 ,5,'Invoice Date:',0,0);
				$pdf->Cell(34 ,5, $result->created_at,0,1);
				 
				 /*
			     $time = strtotime("2010.12.11");
				 $final = date("Y-m-d", strtotime("+1 month", $time));

				 $time = strtotime( $result->created_at );
				 $final = date("Y-m-d", strtotime("+1 month", $time));

				 */

				$time = strtotime( $result->created_at );
				$final = date("Y-m-d", strtotime("+1 month", $time));

				$pdf->Cell(130 ,5,'Reg: 2014/281031/07',0,0);
				$pdf->Cell(25 ,5,'Due Date:',0,0);
				$pdf->Cell(34 ,5,$final,0,1);

				$pdf->Cell(130 ,5,'Unit 6b Monpark Center',0,0);
				$pdf->Cell(25 ,5,'Sales Rep:',0,0);
				$pdf->Cell(34 ,5,$result->sales_rep,0,1);

				$pdf->Cell(130 ,5,'76 Skilpad Street',0,0);
				$pdf->Cell(25 ,5,'Print Date:',0,0);
				$pdf->Cell(34 ,5,date("Y-m-d"),0,1);

				$pdf->Cell(130 ,5,'Monument Park, Pretoria',0,0);
				$pdf->Cell(25 ,5,'',0,0);
				$pdf->Cell(34 ,5,'',0,1);

				$pdf->Cell(130 ,5,'0181',0,0);
				$pdf->Cell(25 ,5,'',0,0);
				$pdf->Cell(34 ,5,'',0,1);

				$pdf->Cell(130 ,5,'',0,0);
				$pdf->Cell(25 ,5,'',0,0);
				$pdf->Cell(34 ,5,'',0,1);


				#BLOCK 3
				$pdf->SetFont('Arial','B',15);
				$pdf->Cell(130 ,5,'Invoice To:',0,0);
				$pdf->Cell(59 ,5,'',0,0);
				$pdf->SetFont('Arial','B',10);
				$pdf->Cell(189 ,10,'',0,1);


				#HERE I AM GOING TO PUT IN THE INVOICE TO DETAILS
				$pdf->Cell(130 ,5,$result->invoice_recipient_name,0,0);
				$pdf->Cell(25 ,5,'',0,0);
				$pdf->Cell(34 ,5,'',0,1);

				$pdf->Cell(130 ,5,$result->recipient_address_line1,0,0);
				$pdf->Cell(25 ,5,'',0,0);
				$pdf->Cell(34 ,5,'',0,1);

				$pdf->Cell(130 ,5,$result->recipient_address_line2,0,0);
				$pdf->Cell(25 ,5,'',0,0);
				$pdf->Cell(34 ,5,'',0,1);

				$pdf->Cell(130 ,5,$result->recipient_address_line3,0,0);
				$pdf->Cell(25 ,5,'',0,0);
				$pdf->Cell(34 ,5,'',0,1);

				$pdf->Cell(130 ,5,$result->recipient_address_line4,0,0);
				$pdf->Cell(25 ,5,'',0,0);
				$pdf->Cell(34 ,5,'',0,1);




				#BLOCK 4
				$pdf->Cell(50 ,10,'',0,1);

				$pdf->SetFont('Arial','B',10);
				/*Heading Of the table*/
				$pdf->Cell(10 ,6,'No',1,0,'C');
				$pdf->Cell(80 ,6,'Description',1,0,'C');
				$pdf->Cell(23 ,6,'Quantity',1,0,'C');
				$pdf->Cell(40 ,6,'Unit Price',1,0,'C');
				/*
				//$pdf->Cell(30 ,6,'Unit Price',1,0,'C');
				//$pdf->Cell(20 ,6,'Sale Tax',1,0,'C');
				//$pdf->Cell(25 ,6,'Total Price',1,1,'C');
				*/
				$pdf->Cell(35 ,6,'Total Price',1,1,'C');/*end of line*/
				/*Heading Of the table end*/
				$pdf->SetFont('Arial','',10);
				    for ($i = 1; $i <= count( $data->results() ); $i++) {
						$pdf->Cell(10 ,6,$i,1,0);
						$pdf->Cell(80 ,6, $result->description,1,0);
						$pdf->Cell(23 ,6,$result->quantity,1,0,'R');
						/*
						$pdf->Cell(30 ,6,'R35.00',1,0,'R');
						//$pdf->Cell(20 ,6,'10.00',1,0,'R');
						$pdf->Cell(25 ,6,'15100.00',1,1,'R');
						*/
						$pdf->Cell(40 ,6, 'R'. $result->unit_price,1,0,'R');
						$pdf->Cell(35 ,6, 'R'. $result->total_price,1,1,'R');
					}
						
				/*
				$pdf->Cell(118 ,6,'',0,0);
				$pdf->Cell(25 ,6,'Subtotal',0,0);
				$pdf->Cell(45 ,6,'151000.00',1,1,'R');
				*/


				//$pdf->Output();

				//$doc = $pdf->Output('test.pdf', 'S');
				$doc = $pdf->Output('Invoice.pdf', 'S');



			}



		} 




	}


	

}catch( Exception $e ){
	die( $e->getMessage() );
} 




?>