<?php
require_once 'core/init.php';



?>

<!DOCTYPE html>
<html>
<head>
	<title>A.I.S</title>
	<meta name="viewport" content="width=device-width, initial-sacle=1">
	<script type="text/javascript" src="js/jquery.js"></script>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/custom.css">
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
</head>
<body>

	<!-- # NAV -->
	<nav class="nav navbar-inverse">
		<div class="container">
			
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand" href="index.php">Advanced Intelligence System</a>
			</div>

			<div id="navbar" class="collapse navbar-collapse">
				<ul class="nav navbar-nav" id="_links">
		
					<li class=""><a href="index.php">Home</a></li>
					<li class=""><a href="register.php">Add User</a></li>
					<li class=""><a href="">Add Client</a></li>
					<li class=""><a href="billing.php">Billing</a></li>
					<!-- 
					<li id="_li"></li>
					-->

				</ul>
			</div>

		</div>
	</nav>


	<!-- # CONTAINER -->
	<div class="container container-bg">
		<div class="row">

			<div class="col-md-12">
			    <p>
					<div class="well border-color">
					<!-- # WELL <div class="well"> -->

						 					   	 <table class="table">
						 		<thead class="thead-dark">
						 			<tr>
						 				<th colspan="2" ><h3>Billing:</h3></th>
						 			</tr>
						 		</thead>

						 		<tbody>

						 			<!---  #I LIKE IT ITS DIFFERENT
						 			<tr>
						 				<td>
						 					<button class="btn btn-success btn-block">Billing</button>
						 				</td>
						 			</tr>

						 			<tr>
						 				<td>
						 					<button class="btn btn-info btn-block">Invoice History</button>
						 				</td>
						 			</tr>

						 			<tr>
						 				<td>
						 					<button class="btn btn-warning btn-block">Statement</button>
						 				</td>
						 			</tr>
									-->

									<tr>
						 				<td>
						 					<button class="btn btn-success btn-block">Billing</button>
						 				</td>

						 				<td>
						 					<button class="btn btn-info btn-block">Invoice History</button>
						 				</td>
						 			</tr>

						 			<tr>
						 				<td colspan="2">
						 					<button class="btn btn-warning btn-block">Statement</button>
						 				</td>
						 			</tr>	


						 		</tbody>
						 </table>

						 <ul class="list-group">
					   	 <li class="list-group-item">

					   	 <!-- #NAVIGATION BUTTON -->
					   	 <!--  
						    .btn-primary
							.btn-success
							.btn-info
							.btn-warning
							.btn-danger
							
							style="font-family:verdana"><
			
							style="bgcolor: red;"

							img-fluid
					   	 -->


					   	 <!-- 
					   	 <img class="img-responsive" src="images/b1.jpg">  -->
					   	 <!--
					   	 <img class="img-fluid" src="images/b1.jpg" style="width: 100%;height: 95px;">
					   	
					   	 <img class="img-fluid" src="images/b2.png" style="width: 100%;height: 95px;">

 						 <img class="img-fluid img-rounded" src="images/bi1.jpg" style="width: 100%;height: 95px;">
					   	 
					   	  -->
					   	  <img class="img-fluid img-rounded" src="images/bi2.png" style="width: 100%;height: 95px;">
					   	


						 <hr/>


						 <!-- #TABLE 2 -->

					   	 <div id="results" class="text-center">
					 		
					   	 </div>
					   	

						 <form action="" method="post" id="register_form">

						 							 
						 	<div class="table-responsive">
						 	<table class="table">
						 		<!-- <thead class="thead-dark">  black white-text  background-color: #ff0000; -->
						 		<thead class="black white-text"> 
						 			<tr>
						 	
						 				<th class="success" scope="col">NO</th>
								        <th class="success" scope="col">Client Name</th>
								        <th class="success" scope="col">Available Credit</th>
								        <th class="success" scope="col">Load Credit</th>
								        <th class="success" scope="col">Approve</th>
								        <th class="success" scope="col">Auth</th>
								        <th class="success" scope="col">Status</th>
								        <th class="success" scope="col">Date Modified</th>
								        <th class="success" scope="col">Invoice</th>
								        <th class="success" scope="col">Statement</th>

						 			</tr>
						 		</thead>

						 		<tbody>
						 			<tr>
								      <th scope="row">1</th>
								      <td>AMT Autobody</td>

								      <td>
								      	<input type="text" name="phone_number" value="4" class="form-control border-color" disabled>
								      </td>

								      <td>
								      	<input type="text" name="phone_number" id="phone_number" value="" class="form-control border-color">
								      </td>
								      <td><button class="btn btn-primary btn-block">Approve Credit</button></td>
								      <td><button class="btn btn-primary btn-block">De-Activate</button></td>
								      <td>Active</td>
								      <td>2020-11-05 08:52:59</td>
								      <td><button class="btn btn-danger btn-block">Invoice</button></td>
								      <td><button class="btn btn-primary btn-block">Statement</button></td>
								    </tr>

								    <tr>
								      <th scope="row">2</th>
								      <td>Zulu Autobody</td>
								      <td><input type="text" name="phone_number" id="phone_number" value="4" class="form-control border-color" disabled></td>
								      <td><input type="text" name="phone_number" id="phone_number" value="" class="form-control border-color"></td>
								      <td><button class="btn btn-primary btn-block">Approve Credit</button></td>
								      <td><button class="btn btn-primary btn-block">De-Activate</button></td>
								      <td>Active</td>
								      <td>2020-11-09 08:52:59</td>
								      <td><button class="btn btn-danger btn-block">Invoice</button></td>
								      <td><button class="btn btn-primary btn-block">Statement</button></td>
								    </tr>

						 		</tbody>
						 	</table>
						 </div>
						   

					   	  	
					   	  </form>

					   	 </li>
					   	 </ul>

					</div>
				</p>
			</div>			

		</div>
	</div>

	<!-- # FOOTER -->
	
	<footer class="footer navbar-fixed-bottom text-center">
		<p>Copyright <?php echo date('Y'); ?> &copy; A.I.S</p>
	</footer>

</body>
</html>

<!-- Search for People -->
<script type="text/javascript">
$(document).ready( function(){
        
	//ADD HERE, MAYBE IF I CHOOSE TO VALIDATE THIS SIDE


} );

</script>