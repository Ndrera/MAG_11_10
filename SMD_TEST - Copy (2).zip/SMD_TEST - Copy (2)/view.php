<!DOCTYPE html>
<html>
<head>
	<title>View</title>
	<meta name="viewport" content="width=device-width, initial-sacle=1">
	<script type="text/javascript" src="js/jquery.js"></script>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/custom.css">
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
</head>
<body>

	<!-- # NAV -->
	<nav class="nav navbar-inverse">
		<div class="container">
			
			 <div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand" href="">View Stored Data</a>
			</div>

			<div id="navbar" class="collapse navbar-collapse">
				<ul class="nav navbar-nav" id="_links">
					<li class=""><a href="contact.php">Contact Form</a></li>
					<li class=""><a href="view.php">View Stored Data</a></li>
				</ul>
			</div>

		</div>
	</nav>


	<!-- # CONTAINER -->
	<div class="container container-bg">
		<div class="row">

			<div class="col-md-12">
			    <p>
					<div class="well border-color">

						 <ul class="list-group">
					   	 <li class="list-group-item">

						   	 <div id="results" class="text-center">

						   	 </div>

					   	 </li>
					   	 </ul>

					</div>
				</p>
			</div>			

		</div>
	</div>

</body>
</html>

<script type="text/javascript">
$(document).ready( function(){

	//FETCH DATA FROM DATABASE
	fetch_data();

	function fetch_data(){
		$.ajax({
			url:"fetch.php",
			success:function(data){
				$('#results').html(data);
			}
		})
	}

});

</script>