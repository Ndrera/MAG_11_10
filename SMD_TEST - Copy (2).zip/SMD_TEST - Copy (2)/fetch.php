<?php
require_once 'core/init.php';


#FETCH ALL THE DATA FROM DB

$data = DB::getInstance()->query("SELECT * FROM credits");

//var_dump( $data );

$output = '';
$option = '';
$active_button = '';
if( !$data->count() ){
    #NO DATA FOUND IN THE DATABASE
	$output .= "
	<tr>
	    <td>No table records are found on this table.</td>
	</tr>
	";

}else{

	//$json = file_get_contents( 'credits.json' );

	$json = file_get_contents( 'credits.json' );
	$load_credits = json_decode( $json, true);

	/*
	//$option .= '<select name="load_credit" id="load_credit" class="form-control border-color load_credit">';
	$array = json_decode($json_array, true);
		foreach($array as $values) {
		   echo $values['efg'];
		   echo $values['d'];
		   echo $values['a'];
		}
	*/
     
	//var_dump( $load_credits ); die;
	foreach( $load_credits as $values){
		//var_dump( $values["10"] );
		//var_dump( $values);
		//$output .= '<option value=" ' . $values . '" cred=" ' . $values . ' ">' . $values. '</option>' ;
		//$output .= '<option value=" ' . $values . '" cred=" ' . $values . ' ">' . $values. '</option>' ;

		$option .= '<option value=" ' . $values . '" cred=" ' . $values . ' ">' . $values. '</option>' ;

	
		
	}

	//$option .= ' </select>';
	

	 

	/***START HERE
	//$option .= '<select name="load_credit" id="load_credit" class="form-control border-color load_credit">';
	echo '<select name="load_credit" id="load_credit" class="form-control border-color load_credit">';
     
	//var_dump( $load_credits ); die;
	foreach( $load_credits as $values){
		//var_dump( $values["10"] );
		//var_dump( $values);
		//$output .= '<option value=" ' . $values . '" cred=" ' . $values . ' ">' . $values. '</option>' ;
		//$output .= '<option value=" ' . $values . '" cred=" ' . $values . ' ">' . $values. '</option>' ;

		//$option .= '<option value=" ' . $values . '" cred=" ' . $values . ' ">' . $values. '</option>' ;
		echo '<option value=" ' . $values . '" cred=" ' . $values . ' ">' . $values. '</option>' ;
		
	}

	//$option .= ' </select>';
	echo '</select>';
	END HERE ******/


	$x = 1;
	foreach( $data->results() as $result ){

		/*
	    - id
		- client_name / client_credited  varchar(70)
		- client_id			 int(11)
		- available_credit		 int(11)
		- load_credit          [STILL NOT SURE/ NOPE] int(11)
		- credit_status	                 varchar(20)  "Active"	
		- credits_issued_to_date	 int(11)
		- created_at     	DateTime
		- updated_at		DateTime
		- deleted_at		DateTime


		"NO Client Name Available Credit Load Credit Approve Auth Status Date Modified Invoice Statement
		   
		 <select name="cars" id="cars">
		  <option value="volvo">Volvo</option>
		  <option value="saab">Saab</option>
		  <option value="mercedes">Mercedes</option>
		  <option value="audi">Audi</option>
		</select>

		  {credit1:10,credit2:20,credit3:30,credit4:40,credit5:50,credit6:60,credit7:70,credit8:80,credit9:90,credit10:100,credit11:150,credit12:200}

		  $credits = json_decode( $result->load_client );
		  foreach( $credit as $credit ){
	           	//return $credit;
	           	<select name="credits">
				  <option value="">$credit</option>
				</select>
		  }

        <th scope="row">'. $result->id .'</th>

        $array = json_decode($json_array, true);
		foreach($array as $values) {
		   echo $values['efg'];
		   echo $values['d'];
		   echo $values['a'];
		}
		*/

		#JASON DECODE
		//{credit1:10,credit2:20,credit3:30,credit4:40,credit5:50,credit6:60,credit7:70,credit8:80,credit9:90,credit10:100,credit11:150,credit12:200}
		//$arr = json_decode($json, true); // load_credit
		//$json = file_get_contents( );
		//$json = json_encode( $result->load_credit, true);

		/*
		<select name="load_credit" id="load_credit" class="form-control border-color load_credit">
				    <option value="10" cred="10">10</option>
				    <option value="20" cred="20">20</option>
				    <option value="30" cred="20">30</option>
				 </select>
		*/

       


		//<button type="button" name="activate" id="' . $result->id . '" class="btn btn-primary btn-block activate">De-Activate</button>


	  	if( $result->credit_status == "Active" ){
	  		$active_button = '<button type="button" name="activate" id="' . $result->id . '" class="btn btn-primary btn-block activate">De-Activate</button>';
	  	}else{
	  		$active_button = '<button type="button" name="activate" id="' . $result->id . '" class="btn btn-primary btn-block activate">Activate</button>';
	  	}
	   

         
		$output .= '
		    <tr>
		      <th scope="row">'. $result->id .'</th>
		      <th scope="row">' . $result->client_name . '</th>
		      <td><input type="text" name="phone_number" id="phone_number" value=" ' . $result->available_credit . ' " class="form-control border-color" disabled></td>
		      <td> 
	             <select name="load_credit" id="load_credit" class="form-control border-color load_credit">
				   ' . $option . '
				 </select>
		      </td>
		      <td><button type="button" name="approve" id="' . $result->id . '" class="btn btn-primary btn-block approve">Approve Credit</button></td>
		      <td><button type="button" name="confirm" id="' . $result->id . '" class="btn btn-primary btn-block confirm">Confirm</button></td>
		      <td>' . $result->payment . '</td>
		      <td>' . $active_button . '</td>
		      <td>' . $result->credit_status . '</td>
		      <td>' . $result->updated_at . '</td>
		      <td><button type="button" name="invoice" id="' . $result->id . '" class="btn btn-danger btn-block invoice">Invoice</button></td>
		      <td><button type="button" name="statement" id="' . $result->id . '" class="btn btn-primary btn-block statement">Statement</button></td>
		    </tr>
		    ';


		$output .= $x < count( $data->results() ) ? "<hr/>" : "";
		$x++;

		
	}

}



echo $output;

?>