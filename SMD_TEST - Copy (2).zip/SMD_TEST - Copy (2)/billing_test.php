<?php
require_once 'core/init.php';



#BUTTON INVOICER
/*
Click the button, let it redirect to a page
Pull Invoive

Date From:  -  Date TO:


*/

$data = DB::getInstance()->query("SELECT * FROM credits");

//var_dump( $data );

$output = '';
$output_id = '';

if( !$data->count() ){
    #NO DATA FOUND IN THE DATABASE
	$output .= "
	<tr>
	    <td>Zulu Autobody</td>
	</tr>
	";

}else{

	$x = 1;
	foreach( $data->results() as $result ){

		/*
	    - id
		- client_name / client_credited  varchar(70)
		- client_id			 int(11)
		- available_credit		 int(11)
		- load_credit          [STILL NOT SURE/ NOPE] int(11)
		- credit_status	                 varchar(20)  "Active"	
		- credits_issued_to_date	 int(11)
		- created_at     	DateTime
		- updated_at		DateTime
		- deleted_at		DateTime


		"NO Client Name Available Credit Load Credit Approve Auth Status Date Modified Invoice Statement
		   
		 <select name="cars" id="cars">
		  <option value="volvo">Volvo</option>
		  <option value="saab">Saab</option>
		  <option value="mercedes">Mercedes</option>
		  <option value="audi">Audi</option>
		</select>

		  {credit1:10,credit2:20,credit3:30,credit4:40,credit5:50,credit6:60,credit7:70,credit8:80,credit9:90,credit10:100,credit11:150,credit12:200}

		  $credits = json_decode( $result->load_client );
		  foreach( $credit as $credit ){
	           	//return $credit;
	           	<select name="credits">
				  <option value="">$credit</option>
				</select>
		  }

        <th scope="row">'. $result->id .'</th>

        <a href="invoice.php?action.php"></a>
		OR put it in a session

		*/

		

		//Session::put( 'id', $result->id );

		$output .= '
		    <tr>
		      <th scope="row">'. $result->id .'</th>
		      <th scope="row">' . $result->client_name . '</th>
		      <td><input type="text" name="phone_number" id="phone_number" value=" ' . $result->available_credit . ' " class="form-control border-color" disabled></td>
		      <td>
		      	 <select name="credits" class="form-control border-color">
				    <option value="10">10</option>
				    <option value="20">20</option>
				    <option value="30">30</option>
				 </select>
		      </td>
		      <td><button class="btn btn-primary btn-block">Approve Credit</button></td>
		      <td><button class="btn btn-primary btn-block">De-Activate</button></td>
		      <td>' . $result->credit_status . '</td>
		      <td>' . $result->updated_at . '</td>
		      <td>
		      <a href="invoice.php?action= ' . $result->id  . '">
		      	<button type="button" name="invoice" id="' . $result->id . '" class="btn btn-danger btn-block invoice">Invoice</button>
		      </a>
		      </td>
		      <td><button type="button" name="statement" id="' . $result->id . '" class="btn btn-primary btn-block statement">Statement</button></td>
		    </tr>
		    ';

        /*
         <td><button type="button" name="invoice" id="' . $result->id . '" class="btn btn-danger btn-block invoice">Invoice</button></td>
		 <td><button type="button" name="statement" id="' . $result->id . '" class="btn btn-primary btn-block statement">Statement</button></td>
		 */

		$output .= $x < count( $data->results() ) ? "<hr/>" : "";
		$x++;
	}

}



//echo $output;

?>

<!DOCTYPE html>
<html>
<head>
	<title>A.I.S</title>
	<meta name="viewport" content="width=device-width, initial-sacle=1">
	<script type="text/javascript" src="js/jquery.js"></script>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/custom.css">
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
</head>
<body>

	<!-- # NAV -->
	<nav class="nav navbar-inverse">
		<div class="container">
			
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand" href="index.php">Advanced Intelligence System</a>
			</div>

			<div id="navbar" class="collapse navbar-collapse">
				<ul class="nav navbar-nav" id="_links">
		
					<li class=""><a href="index.php">Home</a></li>
					<li class=""><a href="register.php">Add User</a></li>
					<li class=""><a href="">Add Client</a></li>
					<li class=""><a href="billing.php">Billing</a></li>
					<!-- 
					<li id="_li"></li>
					-->



				</ul>
			</div>

		</div>
	</nav>


	<!-- # CONTAINER -->
	<div class="container container-bg">
		<div class="row">

			<div class="col-md-12">
			    <p>
					<div class="well border-color">
					<!-- # WELL <div class="well"> -->

						  <table class="table">
						 		<thead class="thead-dark">
						 			<tr>
						 				<th colspan="2" ><h3>Billing:</h3></th>
						 			</tr>
						 		</thead>

						 		<tbody>

									<tr>
						 				<td>
						 					<button class="btn btn-success btn-block">Billing</button>
						 				</td>

						 				<td>
						 					<button class="btn btn-info btn-block">Invoice History</button>
						 				</td>
						 			</tr>

						 			<tr>
						 				<td colspan="2">
						 					<button class="btn btn-warning btn-block">Statement</button>
						 				</td>
						 			</tr>	


						 		</tbody>
						 </table>

						 <ul class="list-group">
					   	 <li class="list-group-item">

					   	  <img class="img-fluid img-rounded" src="images/bi2.png" style="width: 100%;height: 95px;">
					   	


						 <hr/>


						 <!-- #TABLE 2 -->

					   	 <div id="results" class="text-center">
					 		
					   	 </div>
					   	

						 <form action="" method="post" id="credit_form">
						 							 
						 	<div class="table-responsive">
						 	<table class="table">
						 	
								<thead class="black white-text"> 
						 			<tr>
						 	
						 				<th class="success" scope="col">NO</th>
								        <th class="success" scope="col">Client Name</th>
								        <th class="success" scope="col">Available Credit</th>
								        <th class="success" scope="col">Load Credit</th>
								        <th class="success" scope="col">Approve</th>
								        <th class="success" scope="col">Confirm Payment</th>
								        <th class="success" scope="col">Payment</th>
								        <th class="success" scope="col">Auth</th>
								        <th class="success" scope="col">Status</th>
								        <th class="success" scope="col">Date Modified</th>
								        <th class="success" scope="col">Invoice</th>
								        <th class="success" scope="col">Statement</th>

						 			</tr>
						 		</thead>

						 		<!--
						 		<tbody id="bills_output"><?php //echo $output; ?></tbody>
						 	    -->
						 		<tbody id="bills_output"></tbody>

						 		<tbody id="invoice_output"></tbody>
						 		

						 	</table>
						 </div>
						   

					   	  	
					   	  </form>

					   	 </li>
					   	 </ul>

					</div>
				</p>
			</div>			

		</div>
	</div>

	<!-- # FOOTER -->
	
	<footer class="footer navbar-fixed-bottom text-center">
		<p>Copyright <?php echo date('Y'); ?> &copy; A.I.S</p>
	</footer>

</body>
</html>

<!-- #MODAL FOR INVOICE AND STATEMENT 
<div id="apicrudModal" class="modal fade" role="dialog">
-->
<div id="billModal" class="modal fade" role="dialog">
	<div class="modal-dialog">
		<div class="modal-content">
			
			<form method="post" id="invoice_form">
				
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title">Pull Invoice</h4>
				</div>
				<!-- Modal Body-->
				<div class="modal-body">

					<div class="form-group">
						<label>Date From:</label>
						<input type="date" name="date_from" id="date_from" class="form-control" required />
					</div>
					<div class="form-group">
						<label>Date To:</label>
						<input type="date" name="date_to" id="date_to" class="form-control" required />
					</div>

				</div>
				<!-- Modal Footer -->
				<div class="modal-footer">
					<input type="hidden" name="hidden_id" id="hidden_id" />

					<input type="hidden" name="action" id="action" value="insert" />

					<!-- <input type="submit" name="button_action" id="button_action" class="btn btn-info" value="Print" /> --> 
					<!--<input type="submit" name="button_action" id="button_action" class="btn btn-info print_invoice" value="Print" />
					-->
					<input type="submit" name="print_invoice" id="print_invoice" class="btn btn-info" value="Print" />


					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>

				</div>

			</form>

		</div>
	</div>
</div>

<!-- #MODAL STATEMENT -->
<div id="statementModal" class="modal fade" role="dialog">
	<div class="modal-dialog">
		<div class="modal-content">
			
			<form method="post" id="statement_form">
				
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title">Pull Statement</h4>
				</div>
				<!-- Modal Body-->
				<div class="modal-body">

					<div class="form-group">
						<label>Date From:</label>
						<input type="date" name="statement_date_from" id="statement_date_from" class="form-control" required />
					</div>
					<div class="form-group">
						<label>Date To:</label>
						<input type="date" name="statement_date_to" id="statement_date_to" class="form-control" required />
					</div>

				</div>
				<!-- Modal Footer -->
				<div class="modal-footer">
					<input type="hidden" name="hidden_id" id="hidden_id" />

					<input type="hidden" name="action" id="action" value="insert" />

					<!-- <input type="submit" name="button_action" id="button_action" class="btn btn-info" value="Print" /> --> 
					<!--<input type="submit" name="button_action" id="button_action" class="btn btn-info print_invoice" value="Print" />
					-->
					<input type="submit" name="print_statement" id="print_statement" class="btn btn-info" value="Print" />


					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>

				</div>

			</form>

		</div>
	</div>
</div>



<!-- Search for People -->
<script type="text/javascript">
$(document).ready( function(){

	fetch_data();

	function fetch_data(){

		$.ajax({
			url:"fetch.php",
			success:function(data){

				//$('tbody').html(data);
				$('#bills_output').html(data);
			}
		})
	}

	
	//INVOICE   
	$(document).on('click', '.invoice', function(){

		var id = $(this).attr('id');
		sessionStorage.setItem("_id_now", id);
		//alert( $('#hidden_id').val(id) );
		//$('#apicrudModal').modal('show');
		$('#billModal').modal('show');
		
	    /***
		sessionStorage.SessionName = "SessionData" ,
		sessionStorage.getItem("SessionName") and
		sessionStorage.setItem("SessionName","SessionData");
		***/

	});


	$('#invoice_form').on('submit', function(event){
		event.preventDefault();
			//$('#billModal').modal('hide');
			//alert("Submitted: " + id + " Date From: " + date_from);
			 
			var date_from = $('#date_from').val();
			var date_to = $('#date_to').val();

			var my_id = sessionStorage.getItem("_id_now");
			//alert( my_id);
			//alert( my_id);

			//var form_data = $(this).serialize();
			$.ajax({
				url:"action.php",
				method:"POST",
				//data:form_data,
				data:{id:my_id, date_from:date_from, date_to:date_to },
				success:function(data){

					//alert(data);
					//$('#invoice_output').hide();
					//$('#bills_output').hide(); 
					
					$('#billModal').modal('hide');
					$('#invoice_form')[0].reset(); 

					if( data == 0 ){
						alert("No invoices were gerenated for this dates");
					}else if( data == 1 ){
                        //alert("Redirect to invoice");
                        window.location.href = "invoice.php";
					}
					

				}

			});
			
			


		});


	

	
	/* STATEMENT */
	//#STATEMENT
	$(document).on('click', '.statement', function(){

		//alert(  $(this).attr('id') );

		
		var statement_id = $(this).attr('id');
		sessionStorage.setItem("statement_id", statement_id);
		//alert( $('#hidden_id').val(id) );
		//$('#apicrudModal').modal('show');
		$('#statementModal').modal('show');
		
	   

	});


	$('#statement_form').on('submit', function(event){
		event.preventDefault();
			//$('#billModal').modal('hide');
			//alert("Submitted: " + id + " Date From: " + date_from);
			 
			var statement_date_from = $('#statement_date_from').val();
			var statement_date_to = $('#statement_date_to').val();

			var statement_id = sessionStorage.getItem("statement_id");
			


			//var form_data = $(this).serialize();
			$.ajax({
				//url:"action.php",
				url:"statement_action.php",
				method:"POST",
				//data:form_data,
				data:{statement_id:statement_id, statement_date_from:statement_date_from, statement_date_to:statement_date_to },
				success:function(data){

					//alert(data);
					//$('#invoice_output').hide();
					//$('#bills_output').hide(); 
					
					
					$('#statementModal').modal('hide');
					$('#statement_form')[0].reset(); 

					if( data == 0 ){
						alert("No statements were gerenated for this dates");
					}else if( data == 1 ){
                        //alert("Redirect to invoice");
                        window.location.href = "statement.php";
					}
					
				}

			});
			
		
		});



	    /* APPROVE CREDIT */
		//#APPROVE CREDIT
		/*
		 NOTE: Here i will be procecessing everything in a single button
		 BUTTON [ Approve Credit  (Loads credits)]
		 TB: credits
		- First calculate the invoice amount [ credist * 35 * vat ]
		- add loaded_credits to available_credits
		- save the invoices TB data
		- Then generate a pdf invoice, then send it to the clients_email
		<select name="load_credit" id="load_credit" class="form-control border-color">
				    <option value="10" cred="10">10</option>
				    <option value="20" cred="20">20</option>
				    <option value="30" cred="20">30</option>
				 </select>

		<select name="translanguage" class="translanguage">
		  <option value="0">Please Select Language</option>
		  <option class="transoption" value="1" langid="1">Urdu</option>
		  <option class="transoption" value="2" langid="2">English</option>
		  <option class="transoption" value="3" langid="3">Arabic</option>
		  <option class="transoption" value="4" langid="4">Sindhi</option>
		</select>

		 var value = $(this).find('option:selected').attr("langid");  cred
		 $('#listbox-taskStatus option:selected').data('status');
		 $('#load_credit option:selected').data('cred');
		*/
		$(document).on('click', '.approve', function(){

	        
		/*
		var statement_id = $(this).attr('id');
		sessionStorage.setItem("statement_id", statement_id);
		//alert( $('#hidden_id').val(id) );
		//$('#apicrudModal').modal('show');
		$('#statementModal').modal('show');
		*/

		//var value =$( "#load_credit option:selected" ).val();
        //alert($(this).attr('id'));

        
		        //$("#load_credit")[0].selectedIndex = 0;

		        //var form_data = $(this).serialize();

	        	var approve_id = $(this).attr('id');
	        	var value = $( "#load_credit option:selected" ).val();
	        	//var value = $( "#load_credit" ).val();

				$.ajax({
					//url:"action.php",
					url:"approve.php",
					method:"POST",
					//data:form_data,
					data:{approve_id:approve_id, value:value},
					success:function(data){

						alert(data);
						location.reload(); 
						//$('#invoice_output').hide();
						//$('#bills_output').hide(); 
						
						/***
						$('#statementModal').modal('hide');
						$('#statement_form')[0].reset(); 

						if( data == 0 ){
							alert("No statements were gerenated for this dates");
						}else if( data == 1 ){
	                        //alert("Redirect to invoice");
	                        window.location.href = "statement.php";
						}
						***/
						
					}

				});

		});



		//CONFIRM PAYMENT
		/*
		Then change the "Pending" stutus "Success"
		*/
		$(document).on('click', '.confirm', function(){

			//alert( $(this).attr('id') );
	
        	var confirm_id = $(this).attr('id');
			$.ajax({
				//url:"action.php",
				url:"confirm.php",
				method:"POST",
				//data:form_data,
				data:{confirm_id:confirm_id},
				success:function(data){
					alert(data);
					location.reload(); 
					
					
				}

			});
				

		});



		//ACTIVATE
		$(document).on('click', '.activate', function(){

			//alert( $(this).attr('id') );
	
			
        	var activate_id = $(this).attr('id');
			$.ajax({
				//url:"action.php",
				url:"activate.php",
				method:"POST",
				//data:form_data,
				data:{activate_id:activate_id},
				success:function(data){
					alert(data);
					location.reload(); 
					
					
				}

			});
			
				

		});




	

 


} );

</script>