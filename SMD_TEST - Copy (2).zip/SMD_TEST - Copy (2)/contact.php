<?php

require_once 'core/init.php';

$user = new User();

if( Session::exists('home') ){
    echo "<div class='alert alert-success'>" . Session::flash('home') . "</div>";

}

?>

<!DOCTYPE html>
<html>
<head>
	<title>Contact Form</title>
	<meta name="viewport" content="width=device-width, initial-sacle=1">
	<script type="text/javascript" src="js/jquery.js"></script>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/custom.css">
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
</head>
<body>

	<!-- # NAV -->
	<nav class="nav navbar-inverse">
		<div class="container">
			
		    <div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand" href="">Contact From</a>
			</div>

			<div id="navbar" class="collapse navbar-collapse">
				<ul class="nav navbar-nav" id="_links">
		
					<li class=""><a href="contact.php">Contact Form</a></li>
					<li class=""><a href="view.php">View Stored Data</a></li>
					

				</ul>
			</div>
			

		</div>
	</nav>


	<!-- # CONTAINER -->
	<div class="container container-bg">
		<div class="row">

			<div class="col-md-12">
			    <p>
					<div class="well border-color">

						 <ul class="list-group">
					   	 <li class="list-group-item">

					   	 <div id="results" class="text-center">

					   	 </div>
					   	
						 <form action="" method="post" id="contact_form">
						 	<table class="table">
						 		<thead class="thead-dark">
						 			<tr>
						 				<th colspan="2" ><h3>Contact Us:</h3></th>
						 			</tr>
						 		</thead>

						 		<tbody>
						 			<tr>
						 				<td>
						 					<div class="form-group">
							   	  	 			<label>Name:</label>
							   	  	 			<input type="text" name="name" id="name" value="<?php echo escape( Input::get('name') ); ?>" class="form-control border-color"> 
							   	  	 		</div>
						 				</td>

						 				<td>
							   	  	 		<div class="form-group">
							   	  	 			<label>Email Address:</label>
							   	  	 			<input type="text" name="email" id="email" value="<?php echo escape( Input::get('email') ); ?>" class="form-control border-color">
							   	  	 		</div>
							   	  	 	</td> 
						 			</tr>

						 			<tr>
						 				<td colspan="2">
						 					<div class="form-group">
							   	  	 			<label>Phone Number:</label>
							   	  	 			<input type="text" name="phone_number" id="phone_number" value="<?php echo escape( Input::get('phone_number') ); ?>" class="form-control border-color">
							   	  	 		</div>
						 				</td>
						 			</tr>
								
 								    <?php   $user->randomFormInputFields();  ?>

						 			<tr>
							   	  	 	<td colspan="2">
							   	  	 		<div class="form-group">
							   	  	 			<input type="hidden" name="token" value="<?php echo Token::generate(); ?>"> 
							   	  	 			<input type="hidden" name="action" id="action" value="" >
							   	  	 			<input type="submit" name="submit" value="Submit" class="btn btn-primary btn-block">
							   	  	 		</div>
							   	  	 	</td>
							   	  	 </tr>

						 		</tbody>
						 	</table>
					   	  	
					   	  </form>

					   	 </li>
					   	 </ul>

					</div>
				</p>
			</div>			

		</div>
	</div>

	

</body>
</html>

<script type="text/javascript">
$(document).ready( function(){

	$('#contact_form').on('submit', function( event ){
		event.preventDefault();

		$('#action').val('insert');
		
		if( $('#name').val() == '' ){			
			$('#results').html("<div class='alert alert-danger'>Enter your name. </div>");

		}else if( $('#email').val() == '' ){
			$('#results').html("<div class='alert alert-danger'>Enter your email. </div>");

		}else if( $('#phone_number').val() == '' ){
			$('#results').html("<div class='alert alert-danger'>Enter your phone number. </div>");

		}else{

			var form_data = $(this).serialize();
			$.ajax({
				url: "action.php",
				method: "POST",
				data: form_data,
				success:function( data ){
					$('#results').html(data);
				}
			});
		}
		
	});

} );
</script>