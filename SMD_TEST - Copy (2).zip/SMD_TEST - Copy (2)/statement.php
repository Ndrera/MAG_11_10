<?php

/*call the FPDF library*/
require_once 'core/init.php';
require('fpdf182/fpdf.php');


//var_dump(Input::get('id')); die;
//echo "Are WE GETTING";
//if( Session::exists('id') && Session::exists('date_from') && Session::exists('date_to')){
//if( Session::exists('id') ){
//if( Session::exists('id') && Session::exists('date_from') && Session::exists('date_to')){
/*
Session::put('statement_id', $statement_id);
Session::put('statement_date_from', $statement_date_from);
Session::put('statement_date_to', $statement_date_to);
*/

   	  // echo  Session::flash('output');
	   /*
   	   $credit_id =  Session::get('credit_id');
   	   $date_from =  Session::get('date_from');
   	   $date_to   =  Session::get('date_to'); 
   	   */

   	   $credit_id =  Session::get('statement_id');
   	   $date_from =  Session::get('statement_date_from');
   	   $date_to   =  Session::get('statement_date_to');

//}





$data = DB::getInstance()->query("SELECT * FROM invoices WHERE (created_at BETWEEN '$date_from' AND '$date_to') AND credit_id = $credit_id ");



//var_dump( $data ); die;

if( !$data->count() ){
    #NO DATA FOUND IN THE DATABASE
   

	echo "No statement data found";

}else{
   // echo "Yes We found the data";
	 $x = 1;
	foreach( $data->results() as $result ){
		

       /*A4 width : 219mm*/

		$pdf = new FPDF('P','mm','A4');

		$pdf->AddPage();
		/*output the result*/

		/*set font to arial, bold, 14pt*/
		$pdf->SetFont('Arial','B',20);

		/*Cell(width , height , text , border , end line , [align] )*/

		#HEAGING [ INVOICE ]
		#BLOCK 1
		$pdf->Cell(71 ,10,'',0,0);
		$pdf->Cell(59 ,5,'STATEMENT',0,0);
		$pdf->Cell(59 ,10,'',0,1);

		#SENDER'S ADDRESS AND DETAILS [ e.p Platinum I.C.T ]
		#BLOCK 2
		$pdf->SetFont('Arial','B',15);
		$pdf->Cell(71 ,5,'Invoice From:',0,0);
		$pdf->Cell(59 ,5,'',0,0);
		$pdf->Cell(59 ,5,'Invoice Details:',0,1);

		#$pdf->SetFont('Arial','',10);
		$pdf->SetFont('Arial','B',10);

		#NOTE: IT JUMPS FROM LINE TO LINE
		#NOTE: WHERE YOU WANT TO OMMITE DATA LEAVE BLANK [e.g ,'']
		$pdf->Cell(130 ,5,'',0,0);    //ADDIND SPACE
		$pdf->Cell(25 ,5,'',0,0);
		$pdf->Cell(34 ,5,'',0,1);

		$pdf->Cell(130 ,5,'Platinum ICT (Pty) LTD',0,0);  
		$pdf->Cell(25 ,5,'Cust id:',0,0);
		$pdf->Cell(34 ,5, $result->invoice_no,0,1);

		$pdf->Cell(130 ,5,'VAT No: 4380274177',0,0);
		$pdf->Cell(25 ,5,'Date:',0,0);
		$pdf->Cell(34 ,5, $result->created_at,0,1);
		 
		 /*
	     $time = strtotime("2010.12.11");
		 $final = date("Y-m-d", strtotime("+1 month", $time));

		 $time = strtotime( $result->created_at );
		 $final = date("Y-m-d", strtotime("+1 month", $time));

		 */

		$time = strtotime( $result->created_at );
		$final = date("Y-m-d", strtotime("+1 month", $time));

		$pdf->Cell(130 ,5,'Reg: 2014/281031/07',0,0);
		$pdf->Cell(25 ,5,'Print Date:',0,0);
		$pdf->Cell(34 ,5,date("Y-m-d"),0,1);

		$pdf->Cell(130 ,5,'Unit 6b Monpark Center',0,0);
		$pdf->Cell(25 ,5,'',0,0);
		$pdf->Cell(34 ,5,'',0,1);

		$pdf->Cell(130 ,5,'76 Skilpad Street',0,0);
		$pdf->Cell(25 ,5,'',0,0);
		$pdf->Cell(34 ,5,'',0,1);

		$pdf->Cell(130 ,5,'Monument Park, Pretoria',0,0);
		$pdf->Cell(25 ,5,'',0,0);
		$pdf->Cell(34 ,5,'',0,1);

		$pdf->Cell(130 ,5,'0181',0,0);
		$pdf->Cell(25 ,5,'',0,0);
		$pdf->Cell(34 ,5,'',0,1);

		$pdf->Cell(130 ,5,'',0,0);
		$pdf->Cell(25 ,5,'',0,0);
		$pdf->Cell(34 ,5,'',0,1);


		#BLOCK 3
		$pdf->SetFont('Arial','B',15);
		$pdf->Cell(130 ,5,'Invoice To:',0,0);
		$pdf->Cell(59 ,5,'',0,0);
		$pdf->SetFont('Arial','B',10);
		$pdf->Cell(189 ,10,'',0,1);


		#HERE I AM GOING TO PUT IN THE INVOICE TO DETAILS
		$pdf->Cell(130 ,5,$result->invoice_recipient_name,0,0);
		$pdf->Cell(25 ,5,'',0,0);
		$pdf->Cell(34 ,5,'',0,1);

		$pdf->Cell(130 ,5,$result->recipient_address_line1,0,0);
		$pdf->Cell(25 ,5,'',0,0);
		$pdf->Cell(34 ,5,'',0,1);

		$pdf->Cell(130 ,5,$result->recipient_address_line2,0,0);
		$pdf->Cell(25 ,5,'',0,0);
		$pdf->Cell(34 ,5,'',0,1);

		$pdf->Cell(130 ,5,$result->recipient_address_line3,0,0);
		$pdf->Cell(25 ,5,'',0,0);
		$pdf->Cell(34 ,5,'',0,1);

		$pdf->Cell(130 ,5,$result->recipient_address_line4,0,0);
		$pdf->Cell(25 ,5,'',0,0);
		$pdf->Cell(34 ,5,'',0,1);




		#BLOCK 4
		$pdf->Cell(50 ,10,'',0,1);

		$pdf->SetFont('Arial','B',10);
		/*Heading Of the table*/
		$pdf->Cell(10 ,6,'No',1,0,'C');
		$pdf->Cell(20 ,6,'Date',1,0,'C');
		$pdf->Cell(30 ,6,'Reference',1,0,'C');
		$pdf->Cell(60 ,6,'Description',1,0,'C');
		$pdf->Cell(40 ,6,'Debit',1,0,'C');
		//$pdf->Cell(25 ,6,'Credit',1,0,'C');
		$pdf->Cell(30 ,6,'Credit',1,1,'C');/*end of line*/
		/*Heading Of the table end*/
		$pdf->SetFont('Arial','',10);
		    for ($i = 1; $i <= count( $data->results() ); $i++) {
				$pdf->Cell(10 ,6,$i,1,0);
				$pdf->Cell(20 ,6,$result->created_at,1,0);
				$pdf->Cell(30 ,6, $result->reference,1,0,'R');
				$pdf->Cell(60 ,6, $result->description,1,0,'R');
				$pdf->Cell(40 ,6, 'R'. $result->total_price,1,0,'R');
				$pdf->Cell(30 ,6, '',1,1,'R');
				
				
				
			}
				
		


		$pdf->Output();



	}



} 




?>
