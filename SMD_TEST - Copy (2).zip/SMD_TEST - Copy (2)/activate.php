<?php
require_once 'core/init.php';

/*
- I will get the details from db
- Then check the statuts

FOR "Active" i will decativate
FOR "Inactive" i will activate 


*/

//echo "ACTIVE STATUS";

//echo Input::get('activate_id');
$db = DB::getInstance();

$id = Input::get('activate_id');


$data = $db->query("SELECT credit_status, updated_at FROM credits WHERE id = $id");

if( !$data->count() ){
    #NO DATA FOUND IN THE DATABASE
	echo "No credit data found";

}else{

	 foreach( $data->results() as $result ){
	 	//$result->credit_status;
	 	if( $result->credit_status == "Active" ){
	 		$status = "Inactive";

	 	}else{
	 		$status = "Active";
	 	}


	 }

	// var_dump($statuts);
	// echo $status;
	 


	 
	 #UPDATE THE STATUS
	 try{
	 #UPDATE THE CREDIT  

			$db->update( 'credits', $id, array(	

				'credit_status'      	=> $status,
				'updated_at' 			=> date('Y-m-d H:i:s')
				

			) );

			echo "You have set the credit to " . $status;

	 }catch( Exception $e ){
		die( $e->getMessage() );
	 } 



}
		   


?>