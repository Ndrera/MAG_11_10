<?php
class Token{

	



	/**
	* Generate a token for us
	**/
	public static function generate(){
		return Session::put( Config::get('session/token_name'), md5(uniqid()) );

	}



	public static function check( $token ){
		$tokeName = Config::get('session/token_name');  //"token"
		
		if( Session::exists($tokeName) && $token == Session::get($tokeName) ){
			Session::delete( $tokeName );
			return true;

		}

		return false;

	}



}