<?php
class Session{

	/**
	*  Store the session
	**/
	public static function put( $name, $value ){
		return $_SESSION[$name] = $value;
	}


	/**
	* Check if the session exists
	**/
	public static function exists( $name ){
		return ( isset($_SESSION[$name]) ) ? true : false;
	}


	/**
	* Get of the specified value of the session.
	**/
	public static function get( $name ){
		return $_SESSION[$name];
	}


	/**
    * Delete
	**/
	public static function delete( $name ){
		#You cant just delete, you have to check if the session exists first.
		#Use the exists() method,. Note: its a static method, thats why use [ self:: ]
		if( self::exists($name) ){  //True
			unset( $_SESSION[$name] );   
		}


	}

	/**
	* Flash message
	**/
	public static function flash( $name, $string = '' ){
		#Check if the session exists, get() it, then delete() it
		# Then return it as empty
		if( self::exists($name) ){

			$session = self::get( $name );
			self::delete( $name );
			return $session;

		}else{
			#Otherwise we want to set the session with data
			self::put( $name, $string );
		}

	}


}