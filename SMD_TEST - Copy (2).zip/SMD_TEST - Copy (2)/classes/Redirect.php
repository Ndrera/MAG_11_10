<?php
class Redirect{

	/**
	* Redirect to a  location
	**/
	public static function to( $location = null ){
		if( $location ){

			#404 and other errors
			if( is_numeric($location) ){
				switch ( $location ) {
					case 404:
						header('HTTP/1.0 404 Not Found');
						include( 'includes/errors/404.php' );
						exit();
					break;
					
					#NOTE: You might want to include/add other errors
					
				}
			}


			header('Location: ' . $location);
			exit();

		}

	}


}