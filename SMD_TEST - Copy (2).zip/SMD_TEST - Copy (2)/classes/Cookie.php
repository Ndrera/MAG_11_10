<?php
class Cookie{

	

	/**
	* Check if the cookie exists or not.
	**/
	public static function exists( $name ){
		return ( isset($_COOKIE[$name]) ) ? true : false;
	}


    /**
    * Get a cookie using a cookie name passed as parameters.
    **/
    public static function get( $name ){
    	return $_COOKIE[$name];
    }


    /**
    * Set the cookie
    **/
    public static function put( $name, $value, $expiry ){
    	if( setcookie($name, $value, time() + $expiry, '/') ){
    		return true;
    	}
    	return false;

    }


    /**
    * Delete the cookie
    **/
    public static function delete( $name ){
    	self::put( $name,  '', time() - 1 );
    }





}