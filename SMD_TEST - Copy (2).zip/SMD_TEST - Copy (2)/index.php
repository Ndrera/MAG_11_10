<?php
require_once 'core/init.php';

?>

<!DOCTYPE html>
<html>
<head>
	<title>A.I.S</title>
	<meta name="viewport" content="width=device-width, initial-sacle=1">
	<script type="text/javascript" src="js/jquery.js"></script>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/custom.css">
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
</head>
<body>

	<!-- # NAV -->
	<nav class="nav navbar-inverse">
		<div class="container">
			
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand" href="index.php">Advanced Intelligence System</a>
			</div>

			<div id="navbar" class="collapse navbar-collapse">
				<ul class="nav navbar-nav" id="_links">
		
					<li class=""><a href="index.php">Home</a></li>
					<li class=""><a href="register.php">Add User</a></li>
					<li class=""><a href="">Add Client</a></li>
					<li class=""><a href="billing.php">Billing</a></li>
					<!-- 
					<li id="_li"></li>
					-->

				</ul>
			</div>

		</div>
	</nav>


	<!-- # CONTAINER -->
	<div class="container container-bg">
		<div class="row">


			<div class="col-md-12">
			    <p>
					<div class="well border-color">
					<!-- # WELL <div class="well"> -->
						  
						 
						
						 <!--
						 <img class="img-responsive" src="images/3.jpg">
						 <img class="thumbnail" src="images/3.jpg">
							img-responsive

							 <img class="img-responsive" src="images/15.jpg">
						  -->

						 <img class="img-fluid img-rounded" src="images/15.jpg" style="width: 100%;height: 250px;">



						 <ul class="list-group">
					   	 <li class="list-group-item">


					   	 <!-- #NAVIGATION BUTTON -->



					   	 <div id="success_msg" class="text-center">
					 
					   	 </div>

					   	 <div id="results" class="text-center">
					 
					   	 </div>
					   	
					   	<!--
								 - id						int(11)
								 - trade_name	 	        varchar(30)
								 - registered_name	        varchar(30)
								 - client_code    	        varchar(100)
								 - business_email			varchar(50)
								-->

						 <form action="" method="post" id="search_form">

						 	<div class="table-responsive">

						 	<table class="table">
							  <thead class="thead-dark">
							    <tr>
							      <th class="success" scope="col">#</th>
							      <th class="success" scope="col">Client Name</th>
							      <th class="success" scope="col">Client Code</th>
							      <th class="success" scope="col">Email</th>
							      <th class="success" scope="col">Phone Number</th>
							      <th class="success" scope="col">Created At</th>
							      <th class="success" scope="col">Suspend</th>
							      <th class="success" scope="col">Update</th>
							    </tr>
							  </thead>

							  <!--
							  <tbody>
							    <tr>
							      <th scope="row">1</th>
							      <td>AMT Autobody</td>
							      <td>AT1001M</td>
							      <td>business@amt.co.za</td>
							      <td>0124561781</td>
							      <td>2020-11-05 08:52:59</td>
							      <td><button class="btn btn-danger btn-block">Ban</button></td>
							      <td><button class="btn btn-primary btn-block">Update</button></td>
							    </tr>

							     <tr>
							      <th scope="row">2</th>
							      <td>Delas Autobody</td>
							      <td>DE1001M</td>
							      <td>business@amt.co.za</td>
							      <td>0134561781</td>
							      <td>2020-11-05 08:52:59</td>
							      <td><button class="btn btn-danger btn-block">Ban</button></td>
							      <td><button class="btn btn-primary btn-block">Update</button></td>
							    </tr>

							     <tr>
							      <th scope="row">3</th>
							      <td>Zulu Autobody</td>
							      <td>ZU1001M</td>
							      <td>business@amt.co.za</td>
							      <td>0114561781</td>
							      <td>2020-11-05 08:52:59</td>
							      <td><button class="btn btn-danger btn-block">Ban</button></td>
							      <td><button class="btn btn-primary btn-block">Update</button></td>
							    </tr>
							  
							    
							  </tbody> -->



							  <tbody id="clients_output"></tbody>

							</table>

						</div>

						 	
						 	<!--
						 	<table class="table">
						 		
						 		<thead class="thead-dark">
						 			<tr>
						 				<th colspan="2" ><h3>Current Clients:</h3></th>
						 			</tr>
						 		</thead>

						 		<tbody>
						 			<tr>
						 				<td>
						 					Client Name:
						 				</td>

						 				
						 			</tr>
						 			<tr>
						 				<td>	
							   	  	 		Client Code
							   	  	 	</td>
							   	  	</tr>

						 		</tbody>
						 	</table>
						 	-->
					   	  	
					   	  </form>

					   	 </li>
					   	 </ul>

					</div>
				</p>
			</div>			

		</div>







	</div>

      						



	<!-- # FOOTER -->
	<footer class="footer navbar-fixed-bottom text-center">
		<p>Copyright <?php echo date('Y'); ?> &copy; A.I.S </p>
	</footer>

</body>
</html>

<!-- Search for People -->
<script type="text/javascript">
$(document).ready( function(){

	//NOTE THESE ARE CLIENTS
	fetch_data();

	function fetch_data(){

		$.ajax({
			//url:"fetch.php", //fetch_clients.php
			url:"fetch_clients.php", //fetch_clients.php
			success:function(data){

				//$('tbody').html(data);
				$('#clients_output').html(data);
			}
		})
	}


	//SUSPEND USER: SET 1 True, 0 = False (Not Suspened)
	$(document).on('click', '.suspend', function(){

			//alert( $(this).attr('id') );
			
			
        	var suspend_id = $(this).attr('id');
			$.ajax({
				//url:"action.php",
				//url:"confirm.php",
				url:"suspend.php",
				method:"POST",
				//data:form_data,
				data:{suspend_id:suspend_id},
				success:function(data){
					alert(data);
					location.reload(); 
					
					
				}

			});
			
				

	});



	//EDIT THE CLIENT edit
	$(document).on('click', '.edit', function(){

			alert( $(this).attr('id') );
			
			/*
        	var suspend_id = $(this).attr('id');
			$.ajax({
				//url:"action.php",
				//url:"confirm.php",
				url:"suspend.php",
				method:"POST",
				//data:form_data,
				data:{suspend_id:suspend_id},
				success:function(data){
					alert(data);
					location.reload(); 
					
					
				}

			});
			*/
			
				

	});






}); 

</script>