<?php

$attachment= $pdf->Output('attachment.pdf', 'S');

$mailer->AddStringAttachment($attachment, 'attachment.pdf');

?>